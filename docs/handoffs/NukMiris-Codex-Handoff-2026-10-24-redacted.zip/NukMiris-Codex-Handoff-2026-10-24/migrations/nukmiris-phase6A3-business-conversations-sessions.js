"use strict";

// NukMiris Phase 6A.3 — ADDITIVE multi-business session and human-support storage.
// This is a ONE-TIME structure/data migration, NOT a webhook replacement.
// Run with whatsapp-webhook.js STOPPED; legacy tables and existing POC remain unchanged.
// Sender-number-to-business routing is DEVELOPMENT ONLY; production will route
// by the receiving WhatsApp business number and verified tenant context.

const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');
const dbPath = path.join(__dirname, 'nukmiris-sessions.sqlite');
const required = [
  'businesses', 'business_customers', 'dev_test_business_routes',
  'customer_sessions', 'support_conversations', 'support_messages'
];
let db;
try {
  if (!fs.existsSync(dbPath)) throw new Error('Existing SQLite database not found.');
  db = new DatabaseSync(dbPath);
  const present = new Set(db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(r => r.name));
  const missing = required.filter(t => !present.has(t));
  if (missing.length) throw new Error(`Missing prerequisites: ${missing.join(', ')}. Finish Phase 6A.1/6A.2 first.`);

  // Fail closed rather than silently misallocate any existing support/session data.
  const unmapped = db.prepare(`
    SELECT DISTINCT whatsapp_id FROM (
      SELECT whatsapp_id FROM support_conversations
      UNION ALL SELECT whatsapp_id FROM support_messages
      UNION ALL SELECT customer_id AS whatsapp_id FROM customer_sessions
    ) src
    LEFT JOIN dev_test_business_routes r ON r.sender_whatsapp_id = src.whatsapp_id
    WHERE r.business_id IS NULL
  `).all();
  if (unmapped.length) throw new Error(`Existing support/session numbers lack an explicit test business route: ${unmapped.map(r => r.whatsapp_id).join(', ')}`);
  const orphanMessages = db.prepare(`
    SELECT sm.id FROM support_messages sm
    LEFT JOIN support_conversations sc ON sc.whatsapp_id = sm.whatsapp_id
    WHERE sc.whatsapp_id IS NULL
  `).all();
  if (orphanMessages.length) throw new Error(`Found ${orphanMessages.length} support messages without a conversation. No changes made.`);

  db.close(); db = null;
  const backup = dbPath + `.before-phase6A3-${new Date().toISOString().replace(/[:.]/g, '-')}.bak`;
  fs.copyFileSync(dbPath, backup, fs.constants.COPYFILE_EXCL);
  console.log('Backup created:', backup);

  db = new DatabaseSync(dbPath);
  db.exec('PRAGMA foreign_keys = ON');
  db.exec('BEGIN IMMEDIATE TRANSACTION');
  try {
    db.exec(`
      CREATE TABLE IF NOT EXISTS business_customer_sessions (
        business_id TEXT NOT NULL,
        whatsapp_id TEXT NOT NULL,
        session_json TEXT NOT NULL,
        expires_at INTEGER NOT NULL,
        PRIMARY KEY (business_id, whatsapp_id),
        FOREIGN KEY (business_id) REFERENCES businesses(business_id)
      );
      CREATE INDEX IF NOT EXISTS idx_business_sessions_expiration
        ON business_customer_sessions(expires_at);

      CREATE TABLE IF NOT EXISTS business_support_conversations (
        business_id TEXT NOT NULL,
        whatsapp_id TEXT NOT NULL,
        customer_id TEXT,
        status TEXT NOT NULL CHECK(status IN ('waiting','in_progress','closed')),
        assigned_to TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        PRIMARY KEY (business_id, whatsapp_id),
        FOREIGN KEY (business_id) REFERENCES businesses(business_id),
        FOREIGN KEY (customer_id) REFERENCES business_customers(customer_id)
      );
      CREATE INDEX IF NOT EXISTS idx_business_support_queue
        ON business_support_conversations(business_id, status, updated_at);

      CREATE TABLE IF NOT EXISTS business_support_messages (
        id TEXT PRIMARY KEY,
        business_id TEXT NOT NULL,
        whatsapp_id TEXT NOT NULL,
        direction TEXT NOT NULL,
        message_text TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (business_id, whatsapp_id)
          REFERENCES business_support_conversations(business_id, whatsapp_id)
      );
      CREATE INDEX IF NOT EXISTS idx_business_support_message_history
        ON business_support_messages(business_id, whatsapp_id, created_at);
    `);

    // The key named customer_id in legacy sessions contains the sender WhatsApp ID.
    const sessionsResult = db.prepare(`
      INSERT OR IGNORE INTO business_customer_sessions
        (business_id, whatsapp_id, session_json, expires_at)
      SELECT r.business_id, cs.customer_id, cs.session_json, cs.expires_at
      FROM customer_sessions cs
      JOIN dev_test_business_routes r ON r.sender_whatsapp_id=cs.customer_id
    `).run();

    const conversationsResult = db.prepare(`
      INSERT OR IGNORE INTO business_support_conversations
        (business_id, whatsapp_id, customer_id, status, assigned_to, created_at, updated_at)
      SELECT r.business_id, sc.whatsapp_id, bc.customer_id, sc.status,
        CASE WHEN r.business_id='juanita-nails' THEN sc.assigned_to ELSE NULL END,
        sc.created_at, sc.updated_at
      FROM support_conversations sc
      JOIN dev_test_business_routes r ON r.sender_whatsapp_id=sc.whatsapp_id
      LEFT JOIN business_customers bc ON bc.business_id=r.business_id AND bc.whatsapp_id=sc.whatsapp_id
    `).run();

    const messagesResult = db.prepare(`
      INSERT OR IGNORE INTO business_support_messages
        (id, business_id, whatsapp_id, direction, message_text, created_at)
      SELECT sm.id, r.business_id, sm.whatsapp_id, sm.direction, sm.message_text, sm.created_at
      FROM support_messages sm
      JOIN dev_test_business_routes r ON r.sender_whatsapp_id=sm.whatsapp_id
    `).run();

    // Independent of INSERT OR IGNORE, guarantee every legacy row was copied
    // with exactly the original text, IDs, timestamps and target business.
    const omittedSessions = db.prepare(`
      SELECT COUNT(*) AS n FROM customer_sessions s
      JOIN dev_test_business_routes r ON r.sender_whatsapp_id=s.customer_id
      LEFT JOIN business_customer_sessions bs ON bs.business_id=r.business_id AND bs.whatsapp_id=s.customer_id
        AND bs.session_json=s.session_json AND bs.expires_at=s.expires_at
      WHERE bs.whatsapp_id IS NULL
    `).get().n;
    const omittedConversations = db.prepare(`
      SELECT COUNT(*) AS n FROM support_conversations s
      JOIN dev_test_business_routes r ON r.sender_whatsapp_id=s.whatsapp_id
      LEFT JOIN business_support_conversations b ON b.business_id=r.business_id AND b.whatsapp_id=s.whatsapp_id
        AND b.status=s.status AND b.created_at=s.created_at AND b.updated_at=s.updated_at
      WHERE b.whatsapp_id IS NULL
    `).get().n;
    const omittedMessages = db.prepare(`
      SELECT COUNT(*) AS n FROM support_messages s
      JOIN dev_test_business_routes r ON r.sender_whatsapp_id=s.whatsapp_id
      LEFT JOIN business_support_messages b ON b.id=s.id AND b.business_id=r.business_id
        AND b.whatsapp_id=s.whatsapp_id AND b.direction=s.direction
        AND b.message_text=s.message_text AND b.created_at=s.created_at
      WHERE b.id IS NULL
    `).get().n;
    if (omittedSessions || omittedConversations || omittedMessages) {
      throw new Error(`Copy validation failed (sessions=${omittedSessions}, conversations=${omittedConversations}, messages=${omittedMessages}).`);
    }
    const fkFailures = db.prepare('PRAGMA foreign_key_check').all();
    if (fkFailures.length) throw new Error(`Foreign-key validation failed: ${JSON.stringify(fkFailures)}`);
    db.exec('COMMIT');
    console.log('Phase 6A.3 completed successfully. ALL legacy tables remain unchanged.');
    console.log(`Copied this run: sessions=${sessionsResult.changes}, conversations=${conversationsResult.changes}, messages=${messagesResult.changes}`);
    console.log('Business support conversations:', db.prepare(`
      SELECT business_id, whatsapp_id, status, assigned_to, customer_id
      FROM business_support_conversations ORDER BY business_id, whatsapp_id
    `).all());
    console.log('Message counts by business:', db.prepare(`
      SELECT business_id, COUNT(*) AS messages FROM business_support_messages GROUP BY business_id
    `).all());
    console.log('IMPORTANT: Live WhatsApp still uses legacy sessions/support tables until Phase 6A.4.');
    console.log('IMPORTANT: Google Calendar events have NOT yet been moved or scoped by business.');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
} catch (error) {
  console.error('Phase 6A.3 aborted:', error.message);
  process.exitCode = 1;
} finally {
  if (db) db.close();
}
