"use strict";
// Phase 6B.1: map two existing Google calendars to NukMiris businesses.
// No Google Calendar event writes. Stop the webhook before running.
const fs = require("node:fs");
const path = require("node:path");
const readline = require("node:readline/promises");
const { stdin, stdout } = require("node:process");
const { authenticate } = require("@google-cloud/local-auth");
const { google } = require("googleapis");
const { DatabaseSync, backup } = require("node:sqlite");

const DB_PATH = path.join(__dirname, "nukmiris-sessions.sqlite");
const CREDENTIALS_PATH = path.join(__dirname, "credentials.json");
const BUSINESSES = [
  { id: "juanita-nails", label: "Juanita's Nail Salon" },
  { id: "bernard-grooming", label: "Bernard's Pet Grooming" },
];
const writable = new Set(["owner", "writer"]);

async function main() {
  if (!fs.existsSync(DB_PATH)) throw new Error("Missing existing nukmiris-sessions.sqlite; nothing changed.");
  if (!fs.existsSync(CREDENTIALS_PATH)) throw new Error("Missing credentials.json; nothing changed.");
  const db = new DatabaseSync(DB_PATH);
  const rl = readline.createInterface({ input: stdin, output: stdout });
  try {
    const present = new Set(db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(r => r.name));
    for (const name of ["businesses", "business_settings", "business_customers", "business_support_conversations"]) {
      if (!present.has(name)) throw new Error(`Missing Phase 6A table: ${name}. Nothing changed.`);
    }
    for (const business of BUSINESSES) {
      if (!db.prepare("SELECT 1 FROM businesses WHERE business_id=?").get(business.id)) {
        throw new Error(`Missing business ${business.id}. Nothing changed.`);
      }
    }
    console.log("Connecting to Google Calendar (read-only discovery)...");
    const auth = await authenticate({
      scopes: ["https://www.googleapis.com/auth/calendar"],
      keyfilePath: CREDENTIALS_PATH,
    });
    const calendar = google.calendar({ version: "v3", auth });
    const items = [];
    let pageToken;
    do {
      const response = await calendar.calendarList.list({
        maxResults: 250,
        ...(pageToken ? { pageToken } : {}),
      });
      items.push(...(response.data.items || []));
      pageToken = response.data.nextPageToken;
    } while (pageToken);
    const choices = items.filter(c => c.id && writable.has(c.accessRole));
    if (choices.length < 2) throw new Error("Fewer than two writable calendars found. Nothing changed.");
    console.log("\nWritable calendars visible to the connected Google account:");
    choices.forEach((c, i) => console.log(`  ${i + 1}. ${c.summary} [${c.accessRole}] | ${c.id}`));
    async function select(business) {
      const value = (await rl.question(`\nEnter the calendar number for ${business.label}: `)).trim();
      if (!/^[1-9]\d*$/.test(value)) throw new Error("Invalid choice. Nothing changed.");
      const selected = choices[Number(value) - 1];
      if (!selected) throw new Error("Calendar selection out of range. Nothing changed.");
      return selected;
    }
    const first = await select(BUSINESSES[0]);
    const second = await select(BUSINESSES[1]);
    if (first.id === second.id) throw new Error("Each test business needs a different calendar. Nothing changed.");
    console.log("\nPlease verify these mappings:");
    console.log(`  ${BUSINESSES[0].label} -> ${first.summary} (${first.id})`);
    console.log(`  ${BUSINESSES[1].label} -> ${second.summary} (${second.id})`);
    const confirmation = (await rl.question("\nType SAVE to make a local SQLite backup and store these mappings (anything else cancels): ")).trim();
    if (confirmation !== "SAVE") {
      console.log("Cancelled. Database unchanged.");
      return;
    }
    // Backup API takes a consistent SQLite snapshot (including any WAL state).
    const backupPath = `${DB_PATH}.before-phase6B1-${new Date().toISOString().replace(/[:.]/g, "-")}.bak`;
    await backup(db, backupPath);
    console.log(`Backup created: ${backupPath}`);
    db.exec("PRAGMA foreign_keys=ON");
    db.exec("BEGIN IMMEDIATE");
    try {
      db.exec(`CREATE TABLE IF NOT EXISTS business_calendar_connections (
        business_id TEXT PRIMARY KEY REFERENCES businesses(business_id),
        google_calendar_id TEXT NOT NULL UNIQUE,
        google_calendar_name TEXT NOT NULL,
        connection_mode TEXT NOT NULL DEFAULT 'shared_test_oauth',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )`);
      const existing = db.prepare("SELECT business_id, google_calendar_id FROM business_calendar_connections").all();
      for (const row of existing) {
        const proposed = row.business_id === BUSINESSES[0].id ? first : row.business_id === BUSINESSES[1].id ? second : null;
        if (proposed && row.google_calendar_id !== proposed.id) {
          throw new Error(`Business ${row.business_id} already has another calendar mapping. Aborting to avoid overwriting it.`);
        }
      }
      const insert = db.prepare(`INSERT OR IGNORE INTO business_calendar_connections
        (business_id,google_calendar_id,google_calendar_name,connection_mode,created_at,updated_at)
        VALUES (?, ?, ?, 'shared_test_oauth', ?, ?)`);
      const now = new Date().toISOString();
      insert.run(BUSINESSES[0].id, first.id, first.summary, now, now);
      insert.run(BUSINESSES[1].id, second.id, second.summary, now, now);
      for (const [business, selected] of [[BUSINESSES[0], first], [BUSINESSES[1], second]]) {
        const row = db.prepare("SELECT google_calendar_id FROM business_calendar_connections WHERE business_id=?").get(business.id);
        if (row?.google_calendar_id !== selected.id) throw new Error(`Mapping failed verification for ${business.id}`);
      }
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    console.log("\nPhase 6B.1 completed successfully. Stored business calendar mappings:");
    console.log(db.prepare("SELECT business_id,google_calendar_name,google_calendar_id FROM business_calendar_connections ORDER BY business_id").all());
    console.log("No Google Calendar appointments were created, moved, updated, or deleted.");
    console.log("The WhatsApp app still has calendar operations DISABLED until a later phase.");
  } finally {
    rl.close();
    db.close();
  }
}
main().catch(e => { console.error("Phase 6B.1 stopped:", e.message); process.exitCode = 1; });
