"use strict";

// NukMiris Phase 6A.1 — Additive multi-business database foundation.
// Run from the NukMiris-poc folder while the webhook server is STOPPED.
// This script does NOT alter existing customers, appointments, sessions,
// support conversations, or the currently running WhatsApp routing.

const fs = require("node:fs");
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");

const dbPath = path.join(__dirname, "nukmiris-sessions.sqlite");
const requiredTables = [
  "customers",
  "customer_sessions",
  "support_conversations",
  "support_messages",
];

if (!fs.existsSync(dbPath)) {
  console.error(`STOP: Existing NukMiris database not found: ${dbPath}`);
  process.exit(1);
}

let db;
try {
  db = new DatabaseSync(dbPath);
  const existing = new Set(
    db.prepare("SELECT name FROM sqlite_master WHERE type = 'table'")
      .all().map(row => row.name)
  );
  const missing = requiredTables.filter(name => !existing.has(name));
  if (missing.length) {
    throw new Error(`Unexpected database: missing table(s) ${missing.join(", ")}. Nothing changed.`);
  }
  // Close before backup: the webhook must be stopped, so there should be no active writes.
  db.close();
  db = null;

  const backupPath = dbPath + `.before-phase6A1-${new Date().toISOString().replace(/[:.]/g, "-")}.bak`;
  fs.copyFileSync(dbPath, backupPath, fs.constants.COPYFILE_EXCL);
  console.log(`Backup created: ${backupPath}`);

  db = new DatabaseSync(dbPath);
  db.exec("PRAGMA foreign_keys = ON");
  db.exec("BEGIN IMMEDIATE TRANSACTION");
  try {
    db.exec(`
      CREATE TABLE IF NOT EXISTS businesses (
        business_id TEXT PRIMARY KEY,
        business_name TEXT NOT NULL,
        business_type TEXT NOT NULL,
        time_zone TEXT NOT NULL DEFAULT 'America/Mexico_City',
        status TEXT NOT NULL DEFAULT 'test' CHECK(status IN ('test','active','inactive')),
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS business_settings (
        business_id TEXT PRIMARY KEY,
        working_days_json TEXT NOT NULL,
        opening_time TEXT,
        closing_time TEXT,
        appointment_duration_minutes INTEGER NOT NULL CHECK(appointment_duration_minutes > 0),
        buffer_minutes INTEGER,
        start_interval_minutes INTEGER,
        breaks_json TEXT NOT NULL DEFAULT '[]',
        updated_at TEXT NOT NULL,
        FOREIGN KEY (business_id) REFERENCES businesses(business_id)
      );

      -- Development-only routing: customer WhatsApp sender -> mock business.
      -- This is NOT business-number routing and MUST NOT be used in production.
      CREATE TABLE IF NOT EXISTS dev_test_business_routes (
        sender_whatsapp_id TEXT PRIMARY KEY,
        business_id TEXT NOT NULL,
        notes TEXT NOT NULL,
        FOREIGN KEY (business_id) REFERENCES businesses(business_id)
      );
    `);

    const now = new Date().toISOString();
    const insertBusiness = db.prepare(`
      INSERT OR IGNORE INTO businesses
        (business_id, business_name, business_type, time_zone, status, created_at, updated_at)
      VALUES (?, ?, ?, 'America/Mexico_City', 'test', ?, ?)
    `);
    insertBusiness.run("juanita-nails", "Juanita's Nail Salon", "nail_salon", now, now);
    insertBusiness.run("bernard-grooming", "Bernard's Pet Grooming", "pet_grooming", now, now);

    const insertSettings = db.prepare(`
      INSERT OR IGNORE INTO business_settings
        (business_id, working_days_json, opening_time, closing_time,
         appointment_duration_minutes, buffer_minutes, start_interval_minutes,
         breaks_json, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    // ISO weekday convention: Monday=1, ..., Sunday=7.
    // NULL denotes unspecified, not 0. No assumptions about closing time/intervals.
    insertSettings.run("juanita-nails", JSON.stringify([1,2,3,4,5]), "10:00", null,
      60, 15, null, JSON.stringify([{start:"13:00",end:"14:00",label:"Lunch"}]), now);
    insertSettings.run("bernard-grooming", JSON.stringify([2,3,4,5,6,7]), "11:00", "20:00",
      45, null, null, "[]", now);

    const insertRoute = db.prepare(`
      INSERT OR IGNORE INTO dev_test_business_routes (sender_whatsapp_id, business_id, notes)
      VALUES (?, ?, ?)
    `);
    insertRoute.run("REDACTED_TEST_PHONE_1", "juanita-nails", "Miranda test sender; dev only");
    insertRoute.run("REDACTED_TEST_PHONE_2", "bernard-grooming", "Nukis test sender; dev only");

    db.exec("COMMIT");
    console.log("Phase 6A.1 completed successfully. Existing tables were not migrated.");
    console.log("Businesses:", db.prepare("SELECT business_id, business_name, status FROM businesses ORDER BY business_id").all());
    console.log("Settings:", db.prepare("SELECT business_id, working_days_json, opening_time, closing_time, appointment_duration_minutes, buffer_minutes, breaks_json FROM business_settings ORDER BY business_id").all());
    console.log("Development routes:", db.prepare("SELECT sender_whatsapp_id, business_id FROM dev_test_business_routes ORDER BY business_id").all());
    console.log("IMPORTANT: WhatsApp routing and Google Calendar behavior are unchanged until a later phase.");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
} catch (error) {
  console.error("Phase 6A.1 aborted:", error.message);
  process.exitCode = 1;
} finally {
  if (db) db.close();
}
