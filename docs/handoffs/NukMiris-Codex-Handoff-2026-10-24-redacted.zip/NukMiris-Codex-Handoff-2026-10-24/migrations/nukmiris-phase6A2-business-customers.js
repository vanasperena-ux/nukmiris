"use strict";

// NukMiris Phase 6A.2 — Additive business-specific customer registry.
// Run once (or rerun safely) with the WhatsApp webhook STOPPED.
// Keeps the legacy customers table and every existing workflow untouched.
// Development routing by customer sender number is temporary, NOT production routing.

const fs = require("node:fs");
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");

const dbPath = path.join(__dirname, "nukmiris-sessions.sqlite");
let db;
try {
  if (!fs.existsSync(dbPath)) throw new Error(`Database not found: ${dbPath}`);
  db = new DatabaseSync(dbPath);
  db.exec("PRAGMA foreign_keys = ON");
  const required = ["customers", "businesses", "business_settings", "dev_test_business_routes"];
  const existing = new Set(db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(x => x.name));
  const missing = required.filter(name => !existing.has(name));
  if (missing.length) throw new Error(`Missing prerequisite tables: ${missing.join(", ")}. Run Phase 6A.1 first.`);

  // Never silently drop or guess a business for an existing registered customer.
  const unmapped = db.prepare(`
    SELECT c.whatsapp_id, c.full_name
    FROM customers c
    LEFT JOIN dev_test_business_routes r ON r.sender_whatsapp_id = c.whatsapp_id
    WHERE r.business_id IS NULL
  `).all();
  if (unmapped.length) {
    throw new Error(`Unmapped existing customers (${unmapped.length}): ${unmapped.map(c => `${c.full_name} (${c.whatsapp_id})`).join(", ")}. Add explicit development route(s) before migrating.`);
  }

  const legacyCount = db.prepare("SELECT COUNT(*) AS n FROM customers").get().n;
  // The program must be stopped. A consistent file backup is made before edits.
  db.close(); db = null;
  const backupPath = `${dbPath}.before-phase6A2-${new Date().toISOString().replace(/[:.]/g, "-")}.bak`;
  fs.copyFileSync(dbPath, backupPath, fs.constants.COPYFILE_EXCL);
  console.log(`Backup created: ${backupPath}`);

  db = new DatabaseSync(dbPath);
  db.exec("PRAGMA foreign_keys = ON");
  db.exec("BEGIN IMMEDIATE TRANSACTION");
  try {
    // Customer is unique within a business, NOT across all NukMiris tenants.
    // The original UUID can be preserved for the initially migrated customer.
    db.exec(`
      CREATE TABLE IF NOT EXISTS business_customers (
        customer_id TEXT PRIMARY KEY,
        business_id TEXT NOT NULL,
        whatsapp_id TEXT NOT NULL,
        full_name TEXT NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (business_id) REFERENCES businesses(business_id),
        UNIQUE (business_id, whatsapp_id)
      );
      CREATE INDEX IF NOT EXISTS idx_business_customers_business
        ON business_customers(business_id);
    `);

    // An existing customer ID must never be repurposed for a different tenant.
    const conflicts = db.prepare(`
      SELECT c.customer_id, c.whatsapp_id
      FROM customers c
      JOIN dev_test_business_routes r ON r.sender_whatsapp_id = c.whatsapp_id
      JOIN business_customers bc ON bc.customer_id = c.customer_id
      WHERE bc.business_id <> r.business_id OR bc.whatsapp_id <> c.whatsapp_id
    `).all();
    if (conflicts.length) throw new Error(`Existing business customer ID conflicts: ${JSON.stringify(conflicts)}`);

    const insert = db.prepare(`
      INSERT OR IGNORE INTO business_customers
        (customer_id, business_id, whatsapp_id, full_name, created_at, updated_at)
      SELECT c.customer_id, r.business_id, c.whatsapp_id, c.full_name, c.created_at, c.updated_at
      FROM customers c
      JOIN dev_test_business_routes r ON r.sender_whatsapp_id = c.whatsapp_id
    `);
    const result = insert.run();

    // Ensure every legacy registration has landed in the intended business.
    const missingMigrated = db.prepare(`
      SELECT c.whatsapp_id
      FROM customers c
      JOIN dev_test_business_routes r ON r.sender_whatsapp_id = c.whatsapp_id
      LEFT JOIN business_customers bc
        ON bc.business_id = r.business_id AND bc.whatsapp_id = c.whatsapp_id
         AND bc.customer_id = c.customer_id
      WHERE bc.customer_id IS NULL
    `).all();
    if (missingMigrated.length) throw new Error(`Migration verification failed for: ${missingMigrated.map(x => x.whatsapp_id).join(", ")}`);

    const fkErrors = db.prepare("PRAGMA foreign_key_check").all();
    if (fkErrors.length) throw new Error(`Foreign key validation failed: ${JSON.stringify(fkErrors)}`);
    db.exec("COMMIT");
    console.log("Phase 6A.2 completed successfully. Existing customers table was NOT changed.");
    console.log(`Legacy customers: ${legacyCount}; inserted into business_customers this run: ${result.changes}`);
    console.log("Business customers:", db.prepare(`
      SELECT bc.business_id, b.business_name, bc.full_name, bc.whatsapp_id, bc.customer_id
      FROM business_customers bc JOIN businesses b ON b.business_id = bc.business_id
      ORDER BY bc.business_id, bc.full_name
    `).all());
    console.log("IMPORTANT: The WhatsApp webhook still uses the legacy customer registry until Phase 6A.3/6A.4.");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
} catch (error) {
  console.error("Phase 6A.2 aborted:", error.message);
  process.exitCode = 1;
} finally {
  if (db) db.close();
}
