"use strict";

// Phase 6A.5: test multi-business customer identity on a TEMPORARY database copy.
// Does not open the real NukMiris database for writing or modify the webhook.
// Stop the webhook first to ensure a consistent file copy.

const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { randomUUID } = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const realDb = path.join(__dirname, 'nukmiris-sessions.sqlite');
let temporaryDirectory;
let db;
function assert(condition, explanation) {
  if (!condition) throw new Error(explanation);
  console.log(`PASS: ${explanation}`);
}
function count(business, phone) {
  return db.prepare('SELECT COUNT(*) AS n FROM business_customers WHERE business_id = ? AND whatsapp_id = ?').get(business, phone).n;
}
try {
  if (!fs.existsSync(realDb)) throw new Error(`Database not found: ${realDb}`);
  temporaryDirectory = fs.mkdtempSync(path.join(os.tmpdir(), 'nukmiris-6A5-'));
  const testDb = path.join(temporaryDirectory, 'test-copy.sqlite');
  fs.copyFileSync(realDb, testDb);
  console.log('Using a temporary copy of the existing SQLite database.');
  db = new DatabaseSync(testDb);
  db.exec('PRAGMA foreign_keys = ON');
  const expectedTables = ['businesses','business_customers','business_support_conversations','business_support_messages','dev_test_business_routes'];
  const tables = new Set(db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all().map(r => r.name));
  assert(expectedTables.every(t => tables.has(t)), 'Business tables exist');

  const phone = 'REDACTED_TEST_PHONE_1'; // The same example customer identity for both salons
  const juanita = db.prepare('SELECT * FROM business_customers WHERE business_id = ? AND whatsapp_id = ?').get('juanita-nails', phone);
  assert(Boolean(juanita), 'Miranda exists at Juanita');
  assert(count('bernard-grooming', phone) === 0, 'Miranda not yet registered at Bernard in this test copy');

  const now = new Date().toISOString();
  const bernardId = randomUUID();
  db.prepare(`INSERT INTO business_customers (customer_id,business_id,whatsapp_id,full_name,created_at,updated_at)
              VALUES (?,?,?,?,?,?)`).run(bernardId,'bernard-grooming',phone,juanita.full_name,now,now);
  assert(count('juanita-nails',phone) === 1 && count('bernard-grooming',phone) === 1,
    'Same WhatsApp identifier can belong to two separate businesses');
  const juanitaAfter = db.prepare('SELECT customer_id,full_name FROM business_customers WHERE business_id=? AND whatsapp_id=?').get('juanita-nails',phone);
  const bernardAfter = db.prepare('SELECT customer_id,full_name FROM business_customers WHERE business_id=? AND whatsapp_id=?').get('bernard-grooming',phone);
  assert(juanitaAfter.customer_id !== bernardAfter.customer_id, 'Business-specific customer IDs are different');
  assert(juanitaAfter.customer_id === juanita.customer_id, 'Juanita existing customer ID is unchanged');

  const msgQuery = db.prepare('SELECT business_id,whatsapp_id FROM business_support_messages WHERE business_id=?');
  for (const businessId of ['juanita-nails','bernard-grooming']) {
    const messages = msgQuery.all(businessId);
    assert(messages.every(msg => msg.business_id === businessId), `Support messages scoped to ${businessId} (${messages.length} checked)`);
  }
  const invalid = db.prepare('PRAGMA foreign_key_check').all();
  assert(invalid.length === 0, 'No foreign-key violations in test copy');
  console.log('SUMMARY: Phase 6A.5 database isolation test PASSED.');
  console.log('Test insertion was made ONLY in a temporary copy. Original database remains unchanged.');
} catch (err) {
  console.error('Phase 6A.5 test FAILED:', err.message);
  process.exitCode = 1;
} finally {
  if (db) db.close();
  if (temporaryDirectory) fs.rmSync(temporaryDirectory,{recursive:true,force:true});
}
