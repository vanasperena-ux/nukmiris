# First Codex Task — AUDIT ONLY, no modifications

Please inspect this handoff and the user's existing local NukMiris POC repository. Do not execute migrations, send WhatsApp messages, connect to Google OAuth, or touch real appointment events.

1. Compare local `whatsapp-webhook.js` to `src-reference/whatsapp-webhook-v6A4-business-routing-support-only.js` and verify which version is active.
2. Inventory dependencies, JS files, DB migration scripts, git status, and existing tests (without viewing or printing secrets). Do not read `.env` or credential contents.
3. Propose a safe Git repository initialization, `.gitignore`, a backend module structure and staged refactor preserving tested functionality.
4. Inspect Phase 6A.4 scheduling safety gate for bypass paths (text, interactive buttons, stale sessions, background callbacks) and confirm whether it prevents **all** calendar writes. Do not enable Calendar operations.
5. Inspect Phase 6B.1 script for safety: read-only calendar listing, backup correctness, strict mapping of distinct calendar IDs, idempotence, migration transaction and existing DB handling. User has NOT run it.
6. Report database schema and cross-tenant risk, including `business_id` scoping of WhatsApp sessions/messages/customer registry and eventual calendar data. Use synthetic DB fixtures; do not copy live SQLite.
7. Return a concise audit with: verified facts, unresolved questions, prioritized risks, and exactly one recommended next checkpoint. **Await approval before making changes.**

Acceptance: no source edits, no DB edits, no calendar writes, no network calls to WhatsApp or Google; audit report only.
