# Verified project state vs open work

## Confirmed by user checkpoints
- Through Phase 5C.5: WhatsApp Cloud API webhook, customer registration, Google Calendar booking/rescheduling/cancellation, interactive WhatsApp menu and buttons, human support `Menu`, SQLite persistence; two Mexican customer numbers handled after outbound normalization. Booking-enabled version uses single `primary` calendar.
- 6A.1: Created `businesses`, `business_settings`, `dev_test_business_routes`; automatic backup; 2 test businesses.
- 6A.2: Created `business_customers`; 2 existing customer records assigned to respective businesses.
- 6A.3: Created `business_customer_sessions`, `business_support_conversations`, `business_support_messages`; migration output: 1 session, 2 support conversations, 2 messages copied.
- 6A.4: Started business-aware webhook successfully with Google Calendar DISABLED. Sender-number dev mapping worked for both businesses. User tested business-specific menus, human-support persistence and `Menu` state exit.
- 6A.4 inbox SQL query: Juanita 1 message, Bernard 3 messages and no cross-business return with business filter. **Database filtering alone is not production authorization.**
- 6A.5: Read-only temporary-copy isolation test passed. Same WhatsApp identifier registered independently in two businesses with different IDs; original DB unchanged.

## Pending / explicitly NOT verified
- 6B.1: Calendar discovery and database mappings script exists, but USER HAS NOT YET run it successfully. Calendar IDs unknown. Do not claim setup complete.
- Appointment booking under 6A.4: intentionally DISABLED pending per-business Google Calendar integration and authorization controls.
- No business-owner web application or authentication has been implemented.
- Real Meta sender-number-based tenant routing NOT implemented; old `dev_test_business_routes` maps CUSTOMER sender numbers as a simulation.
- Meta second business sender onboarding blocked in business portfolio; formal verification postponed because user has no registered legal business. Dedicated unused SIM was obtained for testing; do not include or require its number in source.
- No hosted infrastructure, billing, production message retries, or robust distributed locking.

## Current test settings
- Juanita's Nail Salon (`juanita-nails`): Monday-Friday, opens 10:00, 60-min service, 15-min buffer, lunch 13:00–14:00; CLOSING TIME UNSET.
- Bernard's Pet Grooming (`bernard-grooming`): Tuesday-Sunday, 11:00–20:00, 45-min service; buffer and breaks UNSET.
- User created two separate Google Calendars visible from same Google account, described as 'Juanita's Nailsalon' and 'Bernard's Grooming Salon'. Actual calendar IDs not yet collected.

## Historical vs current behavior
- v5C.5 has hardcoded `HOURS=[10,11,15]`, weekdays, 60-minute duration, offers three slots and looks 8 days ahead; do not migrate these restrictions into configurable engine.
- v6A.4 may still contain legacy calendar functions in source, but startup and incoming scheduling dispatch are gated. Audit this thoroughly before trusting the safety gate.
- Legacy personal test-customer accounts remain ordinary WhatsApp users, not business sender accounts.
