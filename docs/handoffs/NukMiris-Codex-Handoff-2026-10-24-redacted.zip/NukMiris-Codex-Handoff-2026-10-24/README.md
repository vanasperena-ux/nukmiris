# NukMiris — Codex Engineering Handoff
**Prepared:** 2026-10-24 · **State:** POC / multi-tenant transition · **Owner review required before code changes**

## Start here
1. Read `AGENTS.md` (engineering rules), `PROJECT_STATUS.md` (verified vs pending), and `ARCHITECTURE_AND_PRODUCT.md`.
2. Review `reference/NukMiris-Architecture.png` and the actual local Windows project at `C:\Users\ArjanvanAsperen\Desktop\NukMiris-poc`. The files in `src-reference/` are snapshots, NOT a substitute for reconciling the user's actual project.
3. Review `FIRST_CODEX_TASK.md` and perform **audit only**. Do not update runtime or calendar events yet.
4. Before any refactor, initialize Git locally with `.gitignore` applied, and make a tested baseline commit, excluding real data and credentials.

## Running environment
- Windows, Node.js v24, Express/Node, `googleapis`, `@google-cloud/local-auth`, `luxon`, `dotenv`, built-in `node:sqlite`.
- Local tunnel: Cloudflared; Meta WhatsApp Cloud API v26; webhook listens on port 3000.
- DB path is usually `nukmiris-sessions.sqlite` beside `whatsapp-webhook.js`.
- Google Calendar authorization historically uses `credentials.json` and `primary`; Phase 6A.4 deliberately disables calendar operations.
- Environment secrets exist locally: NEVER ask for them, upload them, print them, or commit them.

## Critical distinction
**Current production-like POC runtime:** `src-reference/whatsapp-webhook-v6A4-business-routing-support-only.js` (business menus/support; ALL scheduling actions safety-disabled).
**Older booking-enabled rollback:** `src-reference/whatsapp-webhook-v5C5-mexican-number-normalization-tested.js` (booking works with shared `primary` calendar; NOT safe for multi-tenant routing).
**Phase 6B.1 mapping script:** `migrations/nukmiris-phase6B1-calendar-mapping.js` prepared, NOT yet user-verified as executed.

## What is included / excluded
Included: source snapshots, additive SQL migrations as JavaScript, original architecture diagram, development handoff documentation.
Excluded: live SQLite data, `.env`, credentials, tokens, uploaded personal data, real calendar IDs (not yet collected).
