# Redaction notice

This is a redacted archival copy of the handoff uploaded on 2026-10-24.
It is reference material, not a deployment or an instruction to run the included scripts.

Privacy changes:
- Embedded personal test phone numbers were replaced consistently with REDACTED_TEST_PHONE_* placeholders.
- The hardcoded webhook verification value in all three source snapshots was replaced with REDACTED_WEBHOOK_VERIFY_TOKEN.
- FILE_MANIFEST_SHA256.txt was regenerated for this copy, including this notice.

All other source bytes and the architecture diagram are unchanged. The snapshots describe historical behavior; this redacted copy is not a runnable, revalidated baseline.
The original uploaded ZIP was left unchanged outside the Git repository and is not included here.

Original filename: NukMiris-Codex-Handoff-2026-10-24.zip
Original archive SHA-256: 6d0e30203d9c814e1627d3e95de8df86c06a77c1cac506e16e13d93cb257d034

Modified source snapshots:
- src-reference/whatsapp-webhook-v5C5-mexican-number-normalization-tested.js
- src-reference/whatsapp-webhook-v6A4-business-routing-support-only.js
- src-reference/whatsapp-webhook-v5C3-cancellation-buttons-tested.js
- migrations/nukmiris-phase6A1-business-foundation.js
- migrations/nukmiris-phase6A5-tenant-isolation-test.js
