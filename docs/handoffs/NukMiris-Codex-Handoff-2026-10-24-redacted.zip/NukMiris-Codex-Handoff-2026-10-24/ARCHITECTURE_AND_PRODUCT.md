# NukMiris — product & target architecture

## Product
Multi-tenant WhatsApp-to-Google Calendar appointment automation for independent small businesses in LATAM (Spanish first; Portuguese later). Customers communicate via WhatsApp, business owners use a mobile-responsive web dashboard (native iOS/Android NOT needed in MVP). Design personas: Juanita salon owner and Alberto customer; test business Bernard pet grooming. Preserve human override, exception queue, reminders/confirmations/rescheduling/no-show state.

## Architectural reference
`reference/NukMiris-Architecture.png` is the original stakeholder architecture and process-flow diagram. It shows API gateway, webhook handler, core conversation/appointment/availability/reminder/notification services, authentication, integration layer, workers, monitoring, DB, billing, analytics, and backup as TARGET architecture. It is NOT proof these are built.

## Multi-tenant invariants
- Business owns its WhatsApp phone number, WhatsApp Business Account and Google Calendar. NukMiris is granted access through authorized integrations; offboarding must not confiscate owner assets.
- Production routing by receiving WhatsApp `metadata.phone_number_id` (and appropriate WABA bindings), not sender. Same WhatsApp customer can patronize different businesses and remain isolated.
- Each business initially has one chosen Google Calendar; Google Calendar is event data of record. Support independent calendars for Juanita and Bernard with separate IDs mapped in database.
- Staff scheduling is a required next design: Juanita may have 3 specialists, preferred known specialist, 'any available', random or even distribution, or priority of new customers to Loli; independent staff hours, time off, service qualifications and buffer. Employee-specific calendar mapping is a future design decision, distinct from one business primary calendar.
- Configuration lives in business settings and future webapp, not source-code constants. Duration, buffer, start-time granularity, breaks, business days and closing time are separate concepts.
- Guard against double booking and stale button actions; validate event ownership and calendar before reschedule/cancel; do not mutate events from other businesses.
- WhatsApp Business app Coexistence onboarding desired for eligible owners; existing personal Messenger users may convert to WhatsApp Business app, but transition and eligibility need verification in Meta. Development Meta test sender is not a real production business sender.
- Production security: authorization per tenant, credential storage, webhook signature verification, OAuth token safety, retries/queue, audit logs and monitoring.

## Deferred
Native mobile app, pricing management, document sending, production billing, formal Meta Tech Provider/Embedded Signup and verification, unless scope is explicitly revised.
